use BD5B6TP2_BrodeurKouma

select * from sys.tables

select * from Employes
select * from Services

select * from TypesEmploye
	

select * from Abonnements
select * from Depenses
select * from TypesAbonnement
select * from PrixDepensesAbonnements

select a.Nom+', '+a.Prenom as 'Nom complet abonn�', d.DateDepense, d.Montant, s.TypeService, e.Nom+', '+e.Prenom as 'Nom complet employ�', p.Prix, p.DepensesObligatoires from Depenses d 
inner join Services s on d.NoService = s.No 
inner join Abonnements a on d.IdAbonnement = a.Id
inner join Employes e on s.NoEmploye = e.No
inner join TypesAbonnement t on t.No = a.NoTypeAbonnement
inner join PrixDepensesAbonnements p on t.No = p.NoTypeAbonnement
where d.No = 

select * from Services
insert into Services(No, TypeService, NoEmploye, Remarque) values
()


select * from Abonnements
select * from Reabonnements


select * from Terrains


select * from Employes where Courriel = 'xkjdc'

select * from Employes

select * from PartiesJouees


