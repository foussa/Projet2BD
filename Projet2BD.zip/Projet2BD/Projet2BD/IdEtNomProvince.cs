﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet2BD
{
    class IdEtNomProvince
    {
        public string idProvince { get; private set; }
        public string nomProvince { get; private set; }
    }
}
