﻿namespace Projet2BD
{
    partial class InscriptionPartieDeGolfJouée
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblAbonne;
            System.Windows.Forms.Label nomTerrainsLabel;
            this.cbNomEtPrenomAbonne = new System.Windows.Forms.ComboBox();
            this.noNomEtPrenomAbonneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbRemarque = new System.Windows.Forms.TextBox();
            this.lblRemarque = new System.Windows.Forms.Label();
            this.lblPointage = new System.Windows.Forms.Label();
            this.btnInscription = new System.Windows.Forms.Button();
            this.noEtNomTerrainsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cbTerrains = new System.Windows.Forms.ComboBox();
            this.nupPointage = new System.Windows.Forms.NumericUpDown();
            lblAbonne = new System.Windows.Forms.Label();
            nomTerrainsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.noNomEtPrenomAbonneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.noEtNomTerrainsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupPointage)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAbonne
            // 
            lblAbonne.AutoSize = true;
            lblAbonne.Location = new System.Drawing.Point(12, 30);
            lblAbonne.Name = "lblAbonne";
            lblAbonne.Size = new System.Drawing.Size(47, 13);
            lblAbonne.TabIndex = 7;
            lblAbonne.Text = "Abonné:";
            // 
            // cbNomEtPrenomAbonne
            // 
            this.cbNomEtPrenomAbonne.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.noNomEtPrenomAbonneBindingSource, "noAbonne", true));
            this.cbNomEtPrenomAbonne.DataSource = this.noNomEtPrenomAbonneBindingSource;
            this.cbNomEtPrenomAbonne.DisplayMember = "nomEtPrenomAbonne";
            this.cbNomEtPrenomAbonne.FormattingEnabled = true;
            this.cbNomEtPrenomAbonne.Location = new System.Drawing.Point(91, 27);
            this.cbNomEtPrenomAbonne.Name = "cbNomEtPrenomAbonne";
            this.cbNomEtPrenomAbonne.Size = new System.Drawing.Size(122, 21);
            this.cbNomEtPrenomAbonne.TabIndex = 8;
            this.cbNomEtPrenomAbonne.ValueMember = "noAbonne";
            // 
            // noNomEtPrenomAbonneBindingSource
            // 
            this.noNomEtPrenomAbonneBindingSource.DataSource = typeof(Projet2BD.noNomEtPrenomAbonne);
            // 
            // tbRemarque
            // 
            this.tbRemarque.Location = new System.Drawing.Point(91, 76);
            this.tbRemarque.Name = "tbRemarque";
            this.tbRemarque.Size = new System.Drawing.Size(122, 20);
            this.tbRemarque.TabIndex = 11;
            // 
            // lblRemarque
            // 
            this.lblRemarque.AutoSize = true;
            this.lblRemarque.Location = new System.Drawing.Point(12, 79);
            this.lblRemarque.Name = "lblRemarque";
            this.lblRemarque.Size = new System.Drawing.Size(59, 13);
            this.lblRemarque.TabIndex = 10;
            this.lblRemarque.Text = "Remarque:";
            // 
            // lblPointage
            // 
            this.lblPointage.AutoSize = true;
            this.lblPointage.Location = new System.Drawing.Point(12, 125);
            this.lblPointage.Name = "lblPointage";
            this.lblPointage.Size = new System.Drawing.Size(52, 13);
            this.lblPointage.TabIndex = 12;
            this.lblPointage.Text = "Pointage:";
            // 
            // btnInscription
            // 
            this.btnInscription.Location = new System.Drawing.Point(254, 94);
            this.btnInscription.Name = "btnInscription";
            this.btnInscription.Size = new System.Drawing.Size(75, 23);
            this.btnInscription.TabIndex = 14;
            this.btnInscription.Text = "Inscription";
            this.btnInscription.UseVisualStyleBackColor = true;
            this.btnInscription.Click += new System.EventHandler(this.btnInscription_Click);
            // 
            // noEtNomTerrainsBindingSource
            // 
            this.noEtNomTerrainsBindingSource.DataSource = typeof(Projet2BD.noEtNomTerrains);
            // 
            // nomTerrainsLabel
            // 
            nomTerrainsLabel.AutoSize = true;
            nomTerrainsLabel.Location = new System.Drawing.Point(12, 172);
            nomTerrainsLabel.Name = "nomTerrainsLabel";
            nomTerrainsLabel.Size = new System.Drawing.Size(71, 13);
            nomTerrainsLabel.TabIndex = 14;
            nomTerrainsLabel.Text = "nom Terrains:";
            // 
            // cbTerrains
            // 
            this.cbTerrains.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.noEtNomTerrainsBindingSource, "nomTerrains", true));
            this.cbTerrains.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.noEtNomTerrainsBindingSource, "noTerrains", true));
            this.cbTerrains.DataSource = this.noEtNomTerrainsBindingSource;
            this.cbTerrains.DisplayMember = "nomTerrains";
            this.cbTerrains.FormattingEnabled = true;
            this.cbTerrains.Location = new System.Drawing.Point(89, 169);
            this.cbTerrains.Name = "cbTerrains";
            this.cbTerrains.Size = new System.Drawing.Size(121, 21);
            this.cbTerrains.TabIndex = 15;
            this.cbTerrains.ValueMember = "noTerrains";
            // 
            // nupPointage
            // 
            this.nupPointage.Location = new System.Drawing.Point(90, 123);
            this.nupPointage.Name = "nupPointage";
            this.nupPointage.Size = new System.Drawing.Size(120, 20);
            this.nupPointage.TabIndex = 16;
            // 
            // InscriptionPartieDeGolfJouée
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 277);
            this.Controls.Add(this.nupPointage);
            this.Controls.Add(nomTerrainsLabel);
            this.Controls.Add(this.cbTerrains);
            this.Controls.Add(this.btnInscription);
            this.Controls.Add(this.lblPointage);
            this.Controls.Add(this.tbRemarque);
            this.Controls.Add(this.lblRemarque);
            this.Controls.Add(lblAbonne);
            this.Controls.Add(this.cbNomEtPrenomAbonne);
            this.Name = "InscriptionPartieDeGolfJouée";
            this.Text = "InscriptionPartieDeGolfJouée";
            this.Load += new System.EventHandler(this.InscriptionPartieDeGolfJouée_Load);
            ((System.ComponentModel.ISupportInitialize)(this.noNomEtPrenomAbonneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.noEtNomTerrainsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupPointage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbNomEtPrenomAbonne;
        private System.Windows.Forms.BindingSource noNomEtPrenomAbonneBindingSource;
        private System.Windows.Forms.TextBox tbRemarque;
        private System.Windows.Forms.Label lblRemarque;
        private System.Windows.Forms.Label lblPointage;
        private System.Windows.Forms.Button btnInscription;
        private System.Windows.Forms.BindingSource noEtNomTerrainsBindingSource;
        private System.Windows.Forms.ComboBox cbTerrains;
        private System.Windows.Forms.NumericUpDown nupPointage;
    }
}