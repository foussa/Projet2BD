namespace Projet2BD
{
    partial class DataClasses1DataContext
    {
    }

    partial class Employe
    {
        public override string ToString()
        {
            return this.Prenom + " " + this.Nom;
        }
    }


    partial class TypesEmploye
    {
        public override string ToString()
        {
            return this.Description;
        }
    }
}