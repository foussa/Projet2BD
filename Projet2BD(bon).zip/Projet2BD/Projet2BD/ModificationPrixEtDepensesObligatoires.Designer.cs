﻿namespace Projet2BD
{
    partial class ModificationPrixEtDepensesObligatoires
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.descriptionPrixEtDepensesObligatoiresDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionPrixEtDepensesObligatoiresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnModifier = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionPrixEtDepensesObligatoiresDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionPrixEtDepensesObligatoiresBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // descriptionPrixEtDepensesObligatoiresDataGridView
            // 
            this.descriptionPrixEtDepensesObligatoiresDataGridView.AutoGenerateColumns = false;
            this.descriptionPrixEtDepensesObligatoiresDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.descriptionPrixEtDepensesObligatoiresDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.descriptionPrixEtDepensesObligatoiresDataGridView.DataSource = this.descriptionPrixEtDepensesObligatoiresBindingSource;
            this.descriptionPrixEtDepensesObligatoiresDataGridView.Location = new System.Drawing.Point(12, 12);
            this.descriptionPrixEtDepensesObligatoiresDataGridView.Name = "descriptionPrixEtDepensesObligatoiresDataGridView";
            this.descriptionPrixEtDepensesObligatoiresDataGridView.Size = new System.Drawing.Size(344, 196);
            this.descriptionPrixEtDepensesObligatoiresDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "strTypeAbonnement";
            this.dataGridViewTextBoxColumn2.HeaderText = "Description Abonnement";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "dcmPrix";
            this.dataGridViewTextBoxColumn3.HeaderText = "Prix";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "dcmDepensesObligatoires";
            this.dataGridViewTextBoxColumn4.HeaderText = "Depenses Obligatoires";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // descriptionPrixEtDepensesObligatoiresBindingSource
            // 
            this.descriptionPrixEtDepensesObligatoiresBindingSource.DataSource = typeof(Projet2BD.descriptionPrixEtDepensesObligatoires);
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(100, 214);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(88, 33);
            this.btnModifier.TabIndex = 2;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            // 
            // ModificationPrixEtDepensesObligatoires
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 450);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.descriptionPrixEtDepensesObligatoiresDataGridView);
            this.Name = "ModificationPrixEtDepensesObligatoires";
            this.Text = "Modification des Prix et des Depenses Obligatoires";
            this.Load += new System.EventHandler(this.ModificationPrixEtDepensesObligatoires_Load);
            ((System.ComponentModel.ISupportInitialize)(this.descriptionPrixEtDepensesObligatoiresDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionPrixEtDepensesObligatoiresBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource descriptionPrixEtDepensesObligatoiresBindingSource;
        private System.Windows.Forms.DataGridView descriptionPrixEtDepensesObligatoiresDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button btnModifier;
    }
}