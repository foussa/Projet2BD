﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet2BD
{

    class descriptionPrixEtDepensesObligatoires
    {
        public int intNoTypeAbonnement { get; private set; }
        public string strTypeAbonnement { get; private set; }
        public decimal dcmPrix { get; private set; }
        public decimal dcmDepensesObligatoires { get; private set; }

    }
}
