﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet2BD
{
    class noEtNomTerrains
    {
        public int noTerrains { get; private set; }
        public string nomTerrains { get; private set; }
    }
}
