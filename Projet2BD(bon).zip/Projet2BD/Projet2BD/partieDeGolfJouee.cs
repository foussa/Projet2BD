﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet2BD
{
    class partieDeGolfJouee
    {
        public string strIdAbonnement { get; private set; }
        public int intNoTerrains { get; private set; }
        public String strDatePartie { get; private set; }
        public double dblPointage { get; private set; }
        public string strRemarque { get; private set; }

    }
}
