﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet2BD
{
    public partial class ModificationPrixEtDepensesObligatoires : Form
    {
        DataClasses1DataContext dataContext = new DataClasses1DataContext();

        public ModificationPrixEtDepensesObligatoires()
        {
            InitializeComponent();
        }

        private void ModificationPrixEtDepensesObligatoires_Load(object sender, EventArgs e)
        {
            descriptionPrixEtDepensesObligatoiresBindingSource.DataSource = from unTypeAbonnement in dataContext.TypesAbonnements
                                                                            join unPrixDepense in dataContext.PrixDepensesAbonnements on unTypeAbonnement.No equals unPrixDepense.NoTypeAbonnement
                                                                            select new
                                                                            {
                                                                                intNoTypeAbonnement = unTypeAbonnement.No,
                                                                                strTypeAbonnement = unTypeAbonnement.Description,
                                                                                dcmPrix = unPrixDepense.Prix,
                                                                                dcmDepensesObligatoires = unPrixDepense.DepensesObligatoires
                                                                            };
        }
    }
}
